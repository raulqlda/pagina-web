<?php
xdebug_info();
?>